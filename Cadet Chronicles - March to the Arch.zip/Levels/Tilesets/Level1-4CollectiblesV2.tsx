<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Level1-4CollectiblesV2" tilewidth="84" tileheight="60" tilecount="4" columns="2">
 <image source="../../Graphics/Sprites/Level1-4CollectiblesV2.png" width="168" height="120"/>
</tileset>
