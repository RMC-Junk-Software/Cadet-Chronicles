<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Lvl3Background" tilewidth="84" tileheight="60" tilecount="30" columns="10">
 <image source="../../Graphics/Textures/Level3_Tiles/Lvl3Background.png" width="840" height="180"/>
</tileset>
