<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Lvl2Background" tilewidth="84" tileheight="60" tilecount="45" columns="9">
 <image source="../../Graphics/Textures/Level2_tiles/Lvl2Background.png" width="756" height="300"/>
</tileset>
