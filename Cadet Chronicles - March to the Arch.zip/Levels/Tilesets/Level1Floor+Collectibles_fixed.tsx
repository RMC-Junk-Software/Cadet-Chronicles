<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Level1Floor+Collectibles_fixed" tilewidth="84" tileheight="60" tilecount="42" columns="6">
 <image source="../../Graphics/Textures/Level1_tiles/Level1Floor+Collectibles.png" width="504" height="420"/>
</tileset>
