<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="rmc flag" tilewidth="84" tileheight="60" tilecount="8" columns="2">
 <image source="../../Graphics/Textures/RMC_Flag.png" width="168" height="240"/>
</tileset>
