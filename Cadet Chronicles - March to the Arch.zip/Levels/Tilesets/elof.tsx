<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="elof" tilewidth="84" tileheight="60" tilecount="2" columns="1">
 <image source="../../Graphics/Character/elof.png" width="84" height="120"/>
</tileset>
