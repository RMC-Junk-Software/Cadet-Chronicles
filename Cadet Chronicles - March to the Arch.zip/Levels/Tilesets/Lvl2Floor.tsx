<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Lvl2Floor" tilewidth="84" tileheight="60" tilecount="30" columns="6">
 <image source="../../Graphics/Textures/Level2_tiles/Lvl2Floor.png" width="504" height="300"/>
</tileset>
