<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Lvl3_Tile" tilewidth="84" tileheight="60" tilecount="50" columns="10">
 <image source="../../Graphics/Textures/Level3_Tiles/Lvl3Floor.png" width="840" height="300"/>
</tileset>
